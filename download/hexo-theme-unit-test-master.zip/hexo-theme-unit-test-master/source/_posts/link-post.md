title: Link Post
date: 2013-12-24 23:30:04
link: http://www.google.com/
---

This is a link post. Clicking on the link should open [Google](http://www.google.com/) in a new tab or window.